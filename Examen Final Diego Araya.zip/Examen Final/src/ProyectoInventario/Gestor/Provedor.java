
package ProyectoInventario.Gestor;

public class Provedor {
    
     private int codigo;
    private String nombre;
    private String telefono;
    private String correo;
    private String qvende;

    public Provedor(int codigo, String nombre, String telefono, String correo, String qvende) {
        this.codigo= codigo;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.qvende = qvende;
    }


    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }


       public Provedor() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getQvende() {
        return qvende;
    }

    public void setQvende(String qvende) {
        this.qvende = qvende;
    }

}