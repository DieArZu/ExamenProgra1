package ProyectoInventario.Gestor;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author diego
 */
public class TableModelProvedor extends AbstractTableModel{

    private String[] columnas = {"Codigo","Nombre","Telefono","Correo","Productos q provee"};
    private List<Provedor> provedor = new ArrayList<>();

    public TableModelProvedor(List<Provedor> prov) {
        this.provedor = prov;
    }
        
        
    @Override
    public int getRowCount() {
        return this.provedor.size();
    }

    @Override
    public int getColumnCount() {
       return this.columnas.length;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
       Object resp = null;
       
       switch(columna){
           case 0 -> resp = this.provedor.get(fila).getCodigo();
            case 1 -> resp = this.provedor.get(fila).getNombre();
            case 2 -> resp = this.provedor.get(fila).getTelefono();
            case 3 -> resp = this.provedor.get(fila).getCorreo();
            case 4 -> resp = this.provedor.get(fila).getQvende();
            }
        return resp;
    }
    
    @Override
    public String getColumnName (int colum){
        return this.columnas[colum];

     }
    
    public void ActualizarTabla (){
        fireTableDataChanged();
        }
            
    public Provedor detalle (int fila){
        return this.provedor.get(fila);
    }
    


    
    
   }
