package ProyectoInventario.Gestor;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author diego
 */
public class BaseDatosProvedores {
 
    private HashMap<Integer,Provedor> listaProvedores = new HashMap<>();
  
    
    public BaseDatosProvedores(){
    
           
    this.listaProvedores.put(1, new Provedor(1,"La casa de los pantalones","24160001","pantalones@gmail.com","Pantalones"));
    this.listaProvedores.put(2, new Provedor(2,"La casa de las camisas","24160001","pantalones@gmail.com","Pantalones"));

    }
    
    
    
    
    
    public List<Provedor> getListaProvedores(){
        return new ArrayList<>(this.listaProvedores.values());
    }
    
    public void setListProvedor(HashMap<Integer,Provedor> listaProvedor){
        
      this.listaProvedores = listaProvedor;   
     } 
    


     public boolean verificarExistencias(String nombre){
         for ( Provedor p : this.listaProvedores.values()){
             if (nombre.toLowerCase().equals(p.getNombre().toLowerCase())){
                return true;
             }
         }
         return false;
     }    

     public int ultimoCodigo (){
    int codigo=0;
    for (Provedor p : this.listaProvedores.values()){
     codigo = p.getCodigo();
    }
        return codigo;
    }
     
     
    public void agregarprov(Provedor p){
        this.listaProvedores.put(p.getCodigo(),p);
         
    }
    
    public void actualizarprov (Provedor p){
     this.listaProvedores.replace(p.getCodigo(), p);
     }
      
    public void borrarprov (Provedor p){
     this.listaProvedores.remove(p.getCodigo());
     }
    
    
   
    
    
     }
        
    