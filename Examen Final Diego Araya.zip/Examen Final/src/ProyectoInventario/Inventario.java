
package ProyectoInventario;

import java.awt.desktop.UserSessionEvent;
import java.util.HashMap;
import javax.swing.JOptionPane;

public class Inventario extends javax.swing.JFrame {
    
       
    String usuario = "Admin";
    String contra = "AaBb";
    boolean login = false;
    int intentos =1;
     
  

    
    @SuppressWarnings("unchecked")
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jButtonEntrar = new javax.swing.JButton();
        JPFcontraseña = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtIntentos = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");
        setPreferredSize(new java.awt.Dimension(550, 450));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(550, 450));
        jPanel1.setLayout(null);

        lblUsuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(51, 0, 204));
        lblUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUsuario.setText("USUARIO");
        jPanel1.add(lblUsuario);
        lblUsuario.setBounds(70, 180, 110, 40);

        txtUsuario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtUsuario);
        txtUsuario.setBounds(190, 190, 130, 22);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 0, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("CONTRASEÑA");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 220, 170, 40);

        jButtonEntrar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButtonEntrar.setForeground(new java.awt.Color(0, 0, 204));
        jButtonEntrar.setText("ACEPTAR");
        jButtonEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEntrarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEntrar);
        jButtonEntrar.setBounds(180, 270, 120, 32);

        JPFcontraseña.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(JPFcontraseña);
        JPFcontraseña.setBounds(190, 230, 130, 22);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ProyectoInventario/Loginn.jpg"))); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(160, 0, 240, 180);

        jLabel1.setText("Usted cuenta con 3 opciones o  / Intentos:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(140, 330, 330, 20);

        txtIntentos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIntentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIntentosActionPerformed(evt);
            }
        });
        jPanel1.add(txtIntentos);
        txtIntentos.setBounds(380, 320, 50, 40);

        jLabel4.setText("Usua = Admin         ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(330, 180, 130, 40);

        jLabel5.setText("Contra = AaBb");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(330, 230, 90, 16);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEntrarActionPerformed
        // TODO add your handling code here:
              
        if (txtUsuario.getText().toLowerCase().equals(usuario.toLowerCase())&& JPFcontraseña.getText().equals(contra)){
            login = true;
           
           
            Menu1 newframe = new Menu1();
           newframe.setVisible(true);
           this.dispose();
            
            
                    
        }
        else{
            
            JOptionPane.showMessageDialog(this, "El usuario o contraseña es incorrecto");
            txtUsuario.setText("");
            JPFcontraseña.setText("");
            intentos= intentos + 1;
            this.txtIntentos.setText(""+intentos);
            if(intentos>3){
                JOptionPane.showMessageDialog(this, "Supero la cantidad de intentos");
                this.dispose();
            
                SisBloquedo newframe = new SisBloquedo();
                newframe.setVisible(true);
                this.dispose();
                }
        }
        
        
    }//GEN-LAST:event_jButtonEntrarActionPerformed

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void txtIntentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIntentosActionPerformed
                    // TODO add your handling code here:
    }//GEN-LAST:event_txtIntentosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventario().setVisible(true);
            }
        });
    }
  
    
    public Inventario() {
        initComponents();
        this.setLocationRelativeTo(null);
         this.txtIntentos.setText(""+intentos);
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField JPFcontraseña;
    private javax.swing.JButton jButtonEntrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JTextField txtIntentos;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
